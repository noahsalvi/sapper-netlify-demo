"use strict";
process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.PORT = process.env.PORT || 3000;

const build_dir = "__sapper__/build";
const execSync = require("child_process").execSync;
// import { execSync } from 'child_process';  // replace ^ if using ES modules
let output = execSync("ls src", { encoding: "utf-8" }); // the default is 'buffer'
console.log("ls:\n", output);

console.log("Starting server on port " + process.env.PORT);
const serverless = require("serverless-http");
const json = require("../__sapper__/build/build.json");
console.log(json);
const server = require("../__sapper__/build/server/server");
console.log("running noah.js");
module.exports.handler = serverless(server);
